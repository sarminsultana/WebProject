<?php

?>

<!DOCTYPE HTML>
<html>
<head>
<title>login</title>



</head>
<body>
<div id="header">


</div>

<div id="cont">

  <h3>Login</h3>
<table width="700" border="0" cellspacing="0" cellpadding="6">
<form id="signupform" name="signupform" method="post" action="admin.php";>
  
    
    <tr><td width="17%" valign="top">User Name:</td><td><input id="id" input name="username"  type="int"  maxlength="16"></td></tr>
    <tr><td width="17%" valign="top"> Password:</td><td><input id="name" input name="password"  type="text"  maxlength="16"></td></tr>   
	<tr><td width="17%" valign="top">Who you are:</td><td><select input id="salary" input name="wur"  type="int"  maxlength="16">
	<option value="admin">Admin</option>
	<option value="subadmin">Instructor</option>
	<option value="user">Student</option> </select></td></tr>

    
   <tr><td width="17%" valign="top"> <button id="signupbtn" input type="submit">Login</button></td></tr>
    
  </form>
</table>
</div>
 </body>
</html>



