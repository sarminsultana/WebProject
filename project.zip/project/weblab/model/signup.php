<?php

?>

<!DOCTYPE HTML>
<html>
<head>
<title>signup</title>



</head>
<body>
<div id="header">
<h1>Signup</h1>

</div>

<div id="cont">
<table width="700" border="0" cellspacing="0" cellpadding="6">
<form id="signupform" name="signupform" method="post" action="insert.php";>
  
  
    
    <tr><td width="17%" valign="top">Id:</td><td><input id="id" input name="id"  type="int"  maxlength="16"></td></tr>
    <tr><td width="17%" valign="top"> Name:</td><td><input id="name" input name="name"  type="text"  maxlength="16"></td></tr>



    <tr><td width="17%" valign="top">Semester:</td><td><select input id="salary" input name="salary"  type="int"  maxlength="16">
<option value="40000">A</option>
	<option value="10000">b</option>
	<option value="5000">c</option> </select></td></tr>

    
   <tr><td width="17%" valign="top"> <button id="signupbtn" input type="submit">Signup</button></td></tr>
    
  </form>
</table>
</div>
 </body>
</html>



